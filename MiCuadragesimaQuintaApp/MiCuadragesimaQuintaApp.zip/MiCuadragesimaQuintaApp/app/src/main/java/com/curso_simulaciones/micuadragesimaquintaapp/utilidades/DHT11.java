package com.curso_simulaciones.micuadragesimaquintaapp.utilidades;


import android.content.Context;
import android.graphics.Color;

public class DHT11 extends GaugeSimple {



    public DHT11(Context context){
        super(context);
        this.setBackgroundColor(Color.WHITE);



    }


}

