package com.curso_simulaciones.midecimanovenaapp.datos;

public class AlmacenDatosRAM {
    public static int tamanoLetraResolucionIncluida;

    public static String nombre1 = "Escribe aquí";
    public static String nombre2 = "Escribe aquí";
    public static boolean habilitar_boton_tres=false;



    public AlmacenDatosRAM() {

    }
}
