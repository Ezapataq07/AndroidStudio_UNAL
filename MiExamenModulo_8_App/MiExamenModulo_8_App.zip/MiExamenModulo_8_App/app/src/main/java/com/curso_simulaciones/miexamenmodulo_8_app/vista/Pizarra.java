package com.curso_simulaciones.miexamenmodulo_8_app.vista;

import android.content.Context;
import android.view.View;

public class Pizarra extends View {

    /**
     * Constructor
     *
     * @param context
     */
    public Pizarra(Context context) {
        super(context);

    }
}
