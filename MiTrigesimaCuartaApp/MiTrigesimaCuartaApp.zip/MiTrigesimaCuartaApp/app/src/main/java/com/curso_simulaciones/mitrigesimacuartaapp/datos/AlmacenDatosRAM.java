package com.curso_simulaciones.mitrigesimacuartaapp.datos;

public class AlmacenDatosRAM {
    public static int dimensioReferencia, alto, ancho;
    public static int tamanoLetraResolucionIncluida;
    public static float datoActual;
    public static float datoBx;
    public static float datoBy;
    public static float datoBz;
    public static float datoB;
    public static boolean configurar;
    public static int periodoMuestreo=500;//en ms
    public static float tiempo;
    public static int nDatos=50;
    public static String path;

}
