package com.curso_simulaciones.mitrigesimasextaapp.datos;

public class AlmacenDatosRAM {

    public static int ancho,alto, dimensionReferencia,tamanoLetraResolucionIncluida;
    public static String conexion_bluetooth;
    public static String rol;

    public static String direccion = "NO CONECTADO";


}
