package com.curso_simulaciones.mivigesimasegundaapp.datos;

public class AlmacenDatosRAM {
    public static float ancho_pantalla, alto_pantalla;



    public AlmacenDatosRAM() {

    }

}
